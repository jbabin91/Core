var searchData=
[
  ['securedataservice',['SecureDataService',['../class_xamarin_1_1_forms_1_1_core_1_1_secure_data_service.html',1,'Xamarin.Forms.Core.SecureDataService'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#a8ccd0b417df1505db82c2dfc8085838a',1,'Xamarin.Forms.Core.CoreBusiness.SecureDataService()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a393e94566044b33e58a02e24a77fd049',1,'Xamarin.Forms.Core.CoreViewModel.SecureDataService()']]],
  ['sendviewmessage',['SendViewMessage',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a77dbe2ccd7c352a03a68d8ada6391942',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['sendviewmessage_3c_20t_20_3e',['SendViewMessage&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#abcd0b58fa299ae556bece83aeab506e8',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['sendviewmodelmessage',['SendViewModelMessage',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a10246149eed19f94230baead076ef6d5',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['sendviewmodelmessage_3c_20t_20_3e',['SendViewModelMessage&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#af7e552f8edaeeca8d47e2d7cf4a1884b',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['shadowcolorproperty',['ShadowColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a94541598c87fee65e260559b6bc7e84f',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowoffsetproperty',['ShadowOffsetProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a2a74fd1a2345cf22861e508cf7e5b565',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowopacityproperty',['ShadowOpacityProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#afb1f9238aed1b5a8eda36dddbd1e6fc0',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowradiusproperty',['ShadowRadiusProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a9e235b3b0bf4c164459d67228b175df8',1,'Xamarin::Forms::Core::CoreButton']]],
  ['snack',['Snack',['../class_xamarin_1_1_forms_1_1_core_1_1_snack.html',1,'Xamarin::Forms::Core']]],
  ['snackbar',['SnackBar',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a44f50ff8a345948a5d99411b293942ec',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['socialmedia',['SocialMedia',['../class_xamarin_1_1_forms_1_1_core_1_1_social_media.html',1,'Xamarin::Forms::Core']]],
  ['stackcontainer',['StackContainer',['../class_xamarin_1_1_forms_1_1_core_1_1_stack_container.html',1,'Xamarin::Forms::Core']]],
  ['starbehavior',['StarBehavior',['../class_xamarin_1_1_forms_1_1_core_1_1_star_behavior.html',1,'Xamarin::Forms::Core']]],
  ['startcolorproperty',['StartColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a92dab18e9417f4cf4799b7e1f74ab70d',1,'Xamarin.Forms.Core.CoreButton.StartColorProperty()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_stack_layout.html#ac80b9b82374e60a1e137e1293eed4e72',1,'Xamarin.Forms.Core.CoreStackLayout.StartColorProperty()']]],
  ['synchronizationcontextremover',['SynchronizationContextRemover',['../struct_xamarin_1_1_forms_1_1_core_1_1_synchronization_context_remover.html',1,'Xamarin::Forms::Core']]],
  ['synctimestamp',['SyncTimeStamp',['../class_xamarin_1_1_forms_1_1_core_1_1_core_settings.html#a5eaafb0fd1db0687b693e510887699e3',1,'Xamarin::Forms::Core::CoreSettings']]]
];
