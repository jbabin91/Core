var searchData=
[
  ['dependencyclarifier',['DependencyClarifier',['../class_xamarin_1_1_forms_1_1_core_1_1_dependency_clarifier.html',1,'Xamarin::Forms::Core']]],
  ['dialogprompt',['DialogPrompt',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#ac8b5c99b96dd064a9ebb94b080dceed3',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['disabledtextcolorproperty',['DisabledTextColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a67e6a189f68f7cc8bda2d51f96d4c678',1,'Xamarin::Forms::Core::CoreButton']]],
  ['disposeservices',['DisposeServices',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a3acf52e270e9cfaeaf30603da5a1d921',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['duration',['Duration',['../class_xamarin_1_1_forms_1_1_core_1_1_snack.html#ae5edff0a1e78f6591bb1c19dfedd25e6',1,'Xamarin::Forms::Core::Snack']]]
];
