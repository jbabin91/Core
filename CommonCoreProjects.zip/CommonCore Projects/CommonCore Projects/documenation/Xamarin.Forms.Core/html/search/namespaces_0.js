var searchData=
[
  ['common',['Common',['../namespace_common.html',1,'']]],
  ['core',['Core',['../namespace_common_1_1_core.html',1,'Common']]]
];
