var searchData=
[
  ['googlesettings',['GoogleSettings',['../class_xamarin_1_1_forms_1_1_core_1_1_google_settings.html',1,'Xamarin::Forms::Core']]],
  ['gridcontainer',['GridContainer',['../class_xamarin_1_1_forms_1_1_core_1_1_grid_container.html',1,'Xamarin::Forms::Core']]],
  ['groupedobservablecollection',['GroupedObservableCollection',['../class_xamarin_1_1_forms_1_1_core_1_1_grouped_observable_collection.html',1,'Xamarin::Forms::Core']]]
];
