var searchData=
[
  ['getallviewmodels',['GetAllViewModels',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#aa01113d2b4ffcc754d1b1e4b300702ea',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['getconverter_3c_20t_20_3e',['GetConverter&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a681fd0b3ba6df47ea5bbc9376387248f',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['getservice_3c_20t_2c_20k_20_3e',['GetService&lt; T, K &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a6bb0747bd56c4d831521a96f8352a392',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['getviewmodel',['GetViewModel',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a8f01abc8897c6395723a2305921b6adc',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['getviewmodel_3c_20t_20_3e',['GetViewModel&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a5a4672199de5cc7576601f0d9983d370',1,'Xamarin::Forms::Core::CoreDependencyService']]],
  ['groupedobservablecollection',['GroupedObservableCollection',['../class_xamarin_1_1_forms_1_1_core_1_1_grouped_observable_collection.html#a52a06acc7a7d78a82455c8822443846a',1,'Xamarin.Forms.Core.GroupedObservableCollection.GroupedObservableCollection(TKey key)'],['../class_xamarin_1_1_forms_1_1_core_1_1_grouped_observable_collection.html#a8b9b2ae989b3496c2e9deff43b607cc3',1,'Xamarin.Forms.Core.GroupedObservableCollection.GroupedObservableCollection(TKey key, IEnumerable&lt; TValue &gt; items)']]]
];
