var searchData=
[
  ['installationid',['InstallationId',['../class_xamarin_1_1_forms_1_1_core_1_1_core_settings.html#a1855c51e5830cd2320ea8fc949a87e2a',1,'Xamarin::Forms::Core::CoreSettings']]]
];
