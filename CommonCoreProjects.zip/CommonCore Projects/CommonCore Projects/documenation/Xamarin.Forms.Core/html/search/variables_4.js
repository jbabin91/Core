var searchData=
[
  ['shadowcolorproperty',['ShadowColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a94541598c87fee65e260559b6bc7e84f',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowoffsetproperty',['ShadowOffsetProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a2a74fd1a2345cf22861e508cf7e5b565',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowopacityproperty',['ShadowOpacityProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#afb1f9238aed1b5a8eda36dddbd1e6fc0',1,'Xamarin::Forms::Core::CoreButton']]],
  ['shadowradiusproperty',['ShadowRadiusProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a9e235b3b0bf4c164459d67228b175df8',1,'Xamarin::Forms::Core::CoreButton']]],
  ['startcolorproperty',['StartColorProperty',['../class_xamarin_1_1_forms_1_1_core_1_1_core_button.html#a92dab18e9417f4cf4799b7e1f74ab70d',1,'Xamarin.Forms.Core.CoreButton.StartColorProperty()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_stack_layout.html#ac80b9b82374e60a1e137e1293eed4e72',1,'Xamarin.Forms.Core.CoreStackLayout.StartColorProperty()']]]
];
