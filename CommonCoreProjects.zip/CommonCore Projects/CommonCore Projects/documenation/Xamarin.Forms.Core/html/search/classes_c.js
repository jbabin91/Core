var searchData=
[
  ['phonemaskbehavior',['PhoneMaskBehavior',['../class_xamarin_1_1_forms_1_1_core_1_1_phone_mask_behavior.html',1,'Xamarin::Forms::Core']]],
  ['popupview',['PopupView',['../class_xamarin_1_1_forms_1_1_core_1_1_popup_view.html',1,'Xamarin::Forms::Core']]],
  ['prompt',['Prompt',['../class_xamarin_1_1_forms_1_1_core_1_1_prompt.html',1,'Xamarin::Forms::Core']]],
  ['propertychangedbehavior',['PropertyChangedBehavior',['../class_xamarin_1_1_forms_1_1_core_1_1_property_changed_behavior.html',1,'Xamarin::Forms::Core']]]
];
