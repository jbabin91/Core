var searchData=
[
  ['corebusiness',['CoreBusiness',['../class_xamarin_1_1_forms_1_1_common_core_1_1_core_business.html',1,'Xamarin::Forms::CommonCore']]],
  ['coreconfiguration',['CoreConfiguration',['../class_xamarin_1_1_forms_1_1_common_core_1_1_core_configuration.html',1,'Xamarin::Forms::CommonCore']]],
  ['coreviewmodel',['CoreViewModel',['../class_xamarin_1_1_forms_1_1_common_core_1_1_core_view_model.html',1,'Xamarin::Forms::CommonCore']]]
];
