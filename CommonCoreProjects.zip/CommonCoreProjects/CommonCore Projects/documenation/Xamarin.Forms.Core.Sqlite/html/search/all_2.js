var searchData=
[
  ['icoresqlmodel',['ICoreSqlModel',['../interface_xamarin_1_1_forms_1_1_core_1_1_i_core_sql_model.html',1,'Xamarin::Forms::Core']]],
  ['isqlitedb',['ISqliteDb',['../interface_xamarin_1_1_forms_1_1_core_1_1_i_sqlite_db.html',1,'Xamarin::Forms::Core']]]
];
