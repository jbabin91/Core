var searchData=
[
  ['sqlitedb',['SqliteDb',['../class_xamarin_1_1_forms_1_1_core_1_1_sqlite_db.html',1,'Xamarin::Forms::Core']]],
  ['sqlitesettings',['SqliteSettings',['../class_xamarin_1_1_forms_1_1_core_1_1_sqlite_settings.html',1,'Xamarin::Forms::Core']]]
];
