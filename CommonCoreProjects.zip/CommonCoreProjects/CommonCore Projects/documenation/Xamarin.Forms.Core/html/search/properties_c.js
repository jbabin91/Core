var searchData=
[
  ['overlaydependency',['OverlayDependency',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a2b48c68de4a15b3907906b55858be8a5',1,'Xamarin::Forms::Core::CoreViewModel']]]
];
