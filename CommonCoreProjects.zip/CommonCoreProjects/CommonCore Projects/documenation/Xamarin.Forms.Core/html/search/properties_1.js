var searchData=
[
  ['backgroundtimer',['BackgroundTimer',['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#aaf5d7c3cedbd843553305259fd1584ed',1,'Xamarin.Forms.Core.CoreBusiness.BackgroundTimer()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a764b19b20e48fda9cfe50a61a2d7bbe8',1,'Xamarin.Forms.Core.CoreViewModel.BackgroundTimer()']]],
  ['beforerefresh',['BeforeRefresh',['../class_xamarin_1_1_forms_1_1_core_1_1_refreshing_collection.html#a58031700597e8d0e86e53b776317473f',1,'Xamarin::Forms::Core::RefreshingCollection']]],
  ['bluroverlay',['BlurOverlay',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#aa2cb3746de671a3ed7a7948a6429d2f6',1,'Xamarin::Forms::Core::CoreViewModel']]]
];
