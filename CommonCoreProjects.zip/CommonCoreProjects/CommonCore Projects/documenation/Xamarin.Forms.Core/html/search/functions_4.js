var searchData=
[
  ['isregistered_3c_20t_20_3e',['IsRegistered&lt; T &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a1c7c5701b607167e4f81fb2f91b443a7',1,'Xamarin::Forms::Core::CoreDependencyService']]]
];
