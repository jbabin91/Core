var searchData=
[
  ['filestore',['FileStore',['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#ae697743338cba4b3b5ff9d054d483688',1,'Xamarin.Forms.Core.CoreBusiness.FileStore()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#ab922da95ae8d825a87b57ebc34c5f041',1,'Xamarin.Forms.Core.CoreViewModel.FileStore()']]]
];
