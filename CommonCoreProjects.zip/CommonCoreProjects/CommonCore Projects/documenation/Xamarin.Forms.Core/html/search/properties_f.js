var searchData=
[
  ['securedataservice',['SecureDataService',['../class_xamarin_1_1_forms_1_1_core_1_1_core_business.html#a8ccd0b417df1505db82c2dfc8085838a',1,'Xamarin.Forms.Core.CoreBusiness.SecureDataService()'],['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a393e94566044b33e58a02e24a77fd049',1,'Xamarin.Forms.Core.CoreViewModel.SecureDataService()']]],
  ['snackbar',['SnackBar',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a44f50ff8a345948a5d99411b293942ec',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['synctimestamp',['SyncTimeStamp',['../class_xamarin_1_1_forms_1_1_core_1_1_core_settings.html#a5eaafb0fd1db0687b693e510887699e3',1,'Xamarin::Forms::Core::CoreSettings']]]
];
