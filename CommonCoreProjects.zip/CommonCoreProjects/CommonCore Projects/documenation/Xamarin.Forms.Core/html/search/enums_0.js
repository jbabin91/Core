var searchData=
[
  ['fabcontrolsize',['FABControlSize',['../namespace_xamarin_1_1_forms_1_1_core_1_1_material_design.html#a0f665feca336b106f06fa6f1c6f3bab5',1,'Xamarin::Forms::Core::MaterialDesign']]]
];
