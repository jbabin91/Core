var searchData=
[
  ['navigation',['Navigation',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a0c6966f8fabdc04223adcb61d2d8d60f',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['needoverridesoftbackbutton',['NeedOverrideSoftBackButton',['../class_xamarin_1_1_forms_1_1_core_1_1_base_pages.html#ab65bff8260adfee60dd0f32d19c179d6',1,'Xamarin::Forms::Core::BasePages']]],
  ['notifybinder',['NotifyBinder',['../class_xamarin_1_1_forms_1_1_core_1_1_core_command.html#a2429bd996bc0ed9de387ca9bf8ec7c4d',1,'Xamarin::Forms::Core::CoreCommand']]]
];
