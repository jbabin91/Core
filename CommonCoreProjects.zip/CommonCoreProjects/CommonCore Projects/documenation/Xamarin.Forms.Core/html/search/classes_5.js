var searchData=
[
  ['fadeoutanimation',['FadeOutAnimation',['../class_xamarin_1_1_forms_1_1_core_1_1_fade_out_animation.html',1,'Xamarin.Forms.Core.FadeOutAnimation'],['../class_xamarin_1_1_forms_1_1_common_core_1_1_fade_out_animation.html',1,'Xamarin.Forms.CommonCore.FadeOutAnimation']]],
  ['filestore',['FileStore',['../class_xamarin_1_1_forms_1_1_core_1_1_file_store.html',1,'Xamarin::Forms::Core']]]
];
