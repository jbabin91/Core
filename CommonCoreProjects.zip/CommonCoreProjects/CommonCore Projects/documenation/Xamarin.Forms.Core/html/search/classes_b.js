var searchData=
[
  ['optimizedobservablecollection',['OptimizedObservableCollection',['../class_xamarin_1_1_forms_1_1_core_1_1_optimized_observable_collection.html',1,'Xamarin::Forms::Core']]],
  ['optimizedobservablecollection_3c_20tvalue_20_3e',['OptimizedObservableCollection&lt; TValue &gt;',['../class_xamarin_1_1_forms_1_1_core_1_1_optimized_observable_collection.html',1,'Xamarin::Forms::Core']]]
];
