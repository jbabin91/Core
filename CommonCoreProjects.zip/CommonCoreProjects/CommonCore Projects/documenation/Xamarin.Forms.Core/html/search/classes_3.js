var searchData=
[
  ['dependencyclarifier',['DependencyClarifier',['../class_xamarin_1_1_forms_1_1_core_1_1_dependency_clarifier.html',1,'Xamarin::Forms::Core']]]
];
