var searchData=
[
  ['mapnavigate',['MapNavigate',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#ac6265cc4c834b5d56b795fdf9d57dcf3',1,'Xamarin::Forms::Core::CoreViewModel']]],
  ['mobileappcenter',['MobileAppCenter',['../class_xamarin_1_1_forms_1_1_core_1_1_mobile_app_center.html',1,'Xamarin::Forms::Core']]]
];
