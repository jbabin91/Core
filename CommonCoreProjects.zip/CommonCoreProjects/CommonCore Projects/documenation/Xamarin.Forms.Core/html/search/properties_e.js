var searchData=
[
  ['refreshfailed',['RefreshFailed',['../class_xamarin_1_1_forms_1_1_core_1_1_refreshing_collection.html#aedc6ef0edee7bab620fea5d1648863db',1,'Xamarin::Forms::Core::RefreshingCollection']]]
];
