var searchData=
[
  ['hasviewmodels',['HasViewModels',['../class_xamarin_1_1_forms_1_1_core_1_1_core_dependency_service.html#a9ba278f1c32e02b5f900d92bd0cdabc4',1,'Xamarin::Forms::Core::CoreDependencyService']]]
];
