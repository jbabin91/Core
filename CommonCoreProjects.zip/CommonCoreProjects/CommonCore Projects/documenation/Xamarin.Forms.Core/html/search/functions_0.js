var searchData=
[
  ['beginmassupdate',['BeginMassUpdate',['../class_xamarin_1_1_forms_1_1_core_1_1_optimized_observable_collection.html#a31c44cef4a1ad59e95fc13311b3729e0',1,'Xamarin::Forms::Core::OptimizedObservableCollection']]]
];
