var searchData=
[
  ['localnotify',['LocalNotify',['../class_xamarin_1_1_forms_1_1_core_1_1_core_view_model.html#a1d148b839741c510a368885a391a8c0d',1,'Xamarin::Forms::Core::CoreViewModel']]]
];
