var searchData=
[
  ['listremoveemptyrows',['ListRemoveEmptyRows',['../class_common_1_1_core_1_1_list_remove_empty_rows.html',1,'Common::Core']]],
  ['localnotification',['LocalNotification',['../class_xamarin_1_1_forms_1_1_core_1_1_local_notification.html',1,'Xamarin::Forms::Core']]],
  ['lowertextconverter',['LowerTextConverter',['../class_xamarin_1_1_forms_1_1_core_1_1_lower_text_converter.html',1,'Xamarin::Forms::Core']]]
];
