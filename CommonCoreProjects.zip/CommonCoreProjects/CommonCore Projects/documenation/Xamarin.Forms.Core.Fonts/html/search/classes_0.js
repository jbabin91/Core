var searchData=
[
  ['fontitem',['FontItem',['../class_xamarin_1_1_forms_1_1_core_1_1_font_item.html',1,'Xamarin::Forms::Core']]],
  ['fontutil',['FontUtil',['../class_xamarin_1_1_forms_1_1_core_1_1_font_util.html',1,'Xamarin::Forms::Core']]]
];
