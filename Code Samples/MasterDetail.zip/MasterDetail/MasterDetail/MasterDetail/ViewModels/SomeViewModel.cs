﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms.Core;

namespace MasterDetail
{
    public class SomeViewModel : CoreViewModel
    {
        private string _someText;
        private int _totalItems;

        public string SomeText { get => _someText; set => SetProperty<string>(ref _someText, value); }
        public int TotalItems { get => _totalItems; set => SetProperty<int>(ref _totalItems, value); }
        public ICommand SomeAction { get; set; }

        public SomeViewModel()
        {
            SomeAction = new CoreCommand(async (obj) =>
            {
                LoadingMessageHUD = "Some action...";
                IsLoadingHUD = true;
                await Task.Delay(new TimeSpan(0, 0, 4));
                IsLoadingHUD = false;
            });
        }

        public override void OnViewMessageReceived(string key, object obj)
        {
            switch (key)
            {
                case CoreSettings.LoadResources:
                    var items = this.SomeLogic.GetSomeData();
                    if (items.error == null)
                    {
                        TotalItems = items.data.Count;
                    }
                    else
                    {
                        this.DialogPrompt.ShowMessage(new Prompt()
                        {
                            Title = "Error",
                            Message = items.error.Message
                        });
                    }
                    break;
            }
        }
    }
}
