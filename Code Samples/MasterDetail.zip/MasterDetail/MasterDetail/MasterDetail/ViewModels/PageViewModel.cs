﻿using System;
using Xamarin.Forms.Core;

namespace MasterDetail.ViewModels
{
    public class PageViewModel: CoreViewModel
    {
        public PageViewModel()
        {
        }

        public override void OnViewMessageReceived(string key, object obj)
        {
           
        }
    }
}
