﻿using System;
using Xamarin.Forms.Core;

namespace SqliteStorage.Views
{
    public class PersonDetail : CorePage<SomeViewModel>
    {
        public PersonDetail()
        {
        }
    }
}
