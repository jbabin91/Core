﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using SqliteStorage.Models;
using Xamarin.Forms.Core;

namespace SqliteStorage
{
    public class SomeViewModel : CoreViewModel
    {
        private string _firstName;
        private string _lastName;

        public string FirstName { get => _firstName; set => SetProperty(ref _firstName, value); }
        public string LastName { get => _lastName; set => SetProperty(ref _lastName, value); }
        public ObservableCollection<Person> People { get; set; } = new ObservableCollection<Person>();
        public ICommand AddPerson { get; set; }

        public SomeViewModel()
        {
            AddPerson = new CoreCommand(async (obj) =>
            {
                var result = await SqliteDb.AddOrUpdate<Person>(new Person()
                {
                    FirstName = this.FirstName,
                    LastName= this.LastName,
                    DOB = DateTime.Now
                });
                var t = result.Success;
            });
        }

        public override void OnViewMessageReceived(string key, object obj)
        {
            switch (key)
            {
                case CoreSettings.LoadResources:
                    Task.Run(async () =>
                    {

                        var results = await SqliteDb.GetAll<Person>();
                        if (results.Success)
                            results.Response.ToObservable();
                        else
                            DialogPrompt.ShowMessage(new Prompt()
                            {
                                Title = "Error",
                                Message = results.Error.Message,
                                ButtonTitles = new string[] { "Okay" }
                            });
                    });
                    break;
            }
        }
    }
}
